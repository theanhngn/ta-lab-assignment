"""
Unit tests for ta_asgn_mna.py and evo_hw_mna.py
"""
import ta_asgn_mna as tapy
from evo_hw_mna import Evo
import pytest
import pandas as pd
import numpy as np


@pytest.fixture
def evo():
    return Evo()


# Test Evo framework constructor
def test_constructor():
    e = Evo()
    assert isinstance(e, Evo), "Did not construct a Evo instance"


@pytest.fixture
def test1():
    data = pd.read_csv('test1.csv', header=None)
    return data


@pytest.fixture
def test2():
    data = pd.read_csv('test2.csv', header=None)
    return data


@pytest.fixture
def test3():
    data = pd.read_csv('test3.csv', header=None)
    return data


@pytest.fixture()
def test4():
    data = pd.DataFrame(np.ones((43, 17)), dtype=int)  # all 1s
    return data


@pytest.fixture()
def test5():
    data = pd.DataFrame(np.zeros((43, 17)), dtype=int)  # all 0s
    return data




# Tests for Objective Functions
def test_overallocation_score(test1, test2, test3):
    test1_file = test1
    test2_file = test2
    test3_file = test3

    assert tapy.overallocation_score_func(test1_file) == 37, "Incorrect overallocation score for test 1 file"
    assert tapy.overallocation_score_func(test2_file) == 41, "Incorrect overallocation score for test 2 file"
    assert tapy.overallocation_score_func(test3_file) == 23, "Incorrect overallocation score for test 3 file"


def test_conflict_score(test1, test2, test3):
    test1_file = test1
    test2_file = test2
    test3_file = test3

    assert tapy.conflict_score_func(test1_file) == 8, "Incorrect conflict score for test 1 file"
    assert tapy.conflict_score_func(test2_file) == 5, "Incorrect conflict score for test 2 file"
    assert tapy.conflict_score_func(test3_file) == 2, "Incorrect conflict score for test 3 file"


def test_undersupport_score(test1, test2, test3):
    test1_file = test1
    test2_file = test2
    test3_file = test3

    assert tapy.undersupport_score_func(test1_file) == 1, "Incorrect under support score for test 1 file"
    assert tapy.undersupport_score_func(test2_file) == 0, "Incorrect under support score for test 2 file"
    assert tapy.undersupport_score_func(test3_file) == 7, "Incorrect under support score for test 3 file"


def test_unwilling_score(test1, test2, test3):
    test1_file = test1
    test2_file = test2
    test3_file = test3

    assert tapy.willingness_score_func_U(test1_file) == 53, "Incorrect unwillingness score for test 1 file"
    assert tapy.willingness_score_func_U(test2_file) == 58, "Incorrect unwillingness score for test 2 file"
    assert tapy.willingness_score_func_U(test3_file) == 43, "Incorrect unwillingness score for test 3 file"


def test_unpreferred_score(test1, test2, test3):
    test1_file = test1
    test2_file = test2
    test3_file = test3

    assert tapy.willingness_score_func_W(test1_file) == 15, "Incorrect unpreferred score for test 1 file"
    assert tapy.willingness_score_func_W(test2_file) == 19, "Incorrect unpreferred score for test 1 file"
    assert tapy.willingness_score_func_W(test3_file) == 10, "Incorrect unpreferred score for test 1 file"




# Extra Tests

# Test Agents
@pytest.fixture
def test_agent1(test1, test2, test3, test4, test5):
    test_solutions = [test1, test2, test3, test4, test5]
    swapped_solution = tapy.random_swapper_col(test_solutions)
    return swapped_solution

def test_agent_df(test_agent1):
    assert test_agent1.shape[0] == 43, "The shape of the dataframe has changed"
    assert test_agent1.shape[1] == 17, "The shape of the dataframe has changed"

@pytest.fixture
def test_agent2(test1, test2, test3, test4, test5):
    test_solutions = [test1, test2, test3, test4, test5]
    swapped_solution = tapy.random_swapper_value(test_solutions)
    return swapped_solution


def test_agent_df2(test_agent2):
    assert test_agent2.shape[0] == 43, "The shape of the dataframe has changed"
    assert test_agent2.shape[1] == 17, "The shape of the dataframe has changed"

@pytest.fixture
def test_agent3(test1, test2, test3, test4, test5):
    test_solutions = [test1, test2, test3, test4, test5]
    swapped_solution = tapy.random_swapper_row_col(test_solutions)
    return swapped_solution


def test_agent_df3(test_agent3):
    assert test_agent3.shape[0] == 43, "The shape of the dataframe has changed"
    assert test_agent3.shape[1] == 17, "The shape of the dataframe has changed"

@pytest.fixture
def test_agent4(test1, test2, test3, test4, test5):
    test_solutions = [test1, test2, test3, test4, test5]
    swapped_solution = tapy.random_swapper_row(test_solutions)
    return swapped_solution

def test_agent_df4(test_agent4):
    assert test_agent4.shape[0] == 43, "The shape of the dataframe has changed"
    assert test_agent4.shape[1] == 17, "The shape of the dataframe has changed"


@pytest.fixture
def test_agent5(test1, test2, test3, test4, test5):
    test_solutions = [test1, test2, test3, test4, test5]
    swapped_solution = tapy.mark_U_as_zeros(test_solutions)
    return swapped_solution

def test_agent_df5(test_agent5):
    assert test_agent5.shape[0] == 43, "The shape of the dataframe has changed"
    assert test_agent5.shape[1] == 17, "The shape of the dataframe has changed"


@pytest.fixture
def test_agent6(test1, test2, test3, test4, test5):
    test_solutions = [test1, test2, test3, test4, test5]
    swapped_solution = tapy.avoid_overallocation(test_solutions)
    return swapped_solution

def test_agent_df6(test_agent6):
    assert test_agent6.shape[0] == 43, "The shape of the dataframe has changed"
    assert test_agent6.shape[1] == 17, "The shape of the dataframe has changed"
