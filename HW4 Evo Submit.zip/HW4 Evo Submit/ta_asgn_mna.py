"""
HW4
Overview: Tester File for running Evo framework
Contains the objective functions and the agent functions
"""
from evo_hw_mna import Evo
import random as rnd
import numpy as np
import pandas as pd


# Global Variables
tas = pd.read_csv('tas.csv')
sections = pd.read_csv('sections.csv')


# Objective Functions
def overallocation_score_func(testfile):
    """ Objective: Counts the number of times a TA have been over-allocated

    Input: 2D numpy array - a selected solution
    Output: Int - Score of the objective
    """
    return np.sum(np.abs(np.where(np.array(tas['max_assigned']) - np.sum(np.array(testfile), axis=1) < 0,
                                  np.array(tas['max_assigned']) - np.sum(np.array(testfile), axis=1), 0)))


def undersupport_score_func(testfile):
    """ Objective: Counts the number of occurrences a section has fewer TAs than required

    Input: 2D numpy array - a selected solution
    Output: Int - Score of the objective"""
    return np.sum(np.abs(np.where(np.sum(testfile, axis=0) - np.array(sections['min_ta']) < 0,
                                  np.sum(testfile, axis=0) - np.array(sections['min_ta']), 0)))


def conflict_score_func(testfile):
    """ Objective: Count the number of occurrences where a TA gets assigned to two sections that run at the same time

    Input: 2D numpy array - a selected solution
    Output: Int - Score of the objective
    """
    return sum(map(lambda row: any(sum(row[conflict] for conflict in conflictgroup) > 1 for conflictgroup in
                                   sections.groupby('daytime')['section'].apply(list)), np.array(testfile)))

def willingness_score_func_U(testfile):
    """ Objective: Count the number of occurrences where a TA get assigned to a section
        where they are unwilling to teach

        Input: 2D numpy array - a selected solution
        Output: Int - Score of the objective
        """
    return sum(1 for row, unw in zip(np.array(testfile), np.array([np.array(
        [col for col in tas.columns if col.isdigit()])[np.where(
        row[[col for col in tas.columns if col.isdigit()]] == 'U')[0]] for _, row in tas.iterrows()], dtype=object))
               for sec in unw if row[int(sec)] == 1)


def willingness_score_func_W(testfile):  # , tas, willing_val):
    """ Objective: Count the number of occurrences where a TA get assigned to a section
        where they are willing but not their top preference

        Input: 2D numpy array - a selected solution
        Output: Int - Score of the objective

    """
    return sum(1 for row, unw in zip(np.array(testfile), np.array([np.array(
        [col for col in tas.columns if col.isdigit()])[np.where(
        row[[col for col in tas.columns if col.isdigit()]] == 'W')[0]] for _, row in tas.iterrows()], dtype=object))
               for sec in unw if row[int(sec)] == 1)


# Agents
def random_swapper_col(solutions):
    """ Swap two random colums

        Input: list - list of solutions
        Output: DataFrame - an updated dataFrame after the changes made by the agent
    """
    n_sol = len(solutions) # get the number of available solutions
    L = solutions[rnd.randrange(0, n_sol)]  # pick a df in random from the solutions

    num_cols = L.shape[1]

    # pick two column values
    i = rnd.randrange(0, num_cols)
    j = rnd.randrange(0, num_cols)

    # swap the columns
    L[i], L[j] = L[j], L[i]
    return L


def random_swapper_row(solutions):
    """ Swap two random rows

        Input: list - list of solutions
        Output: DataFrame - an updated dataFrame after the changes made by the agent

    """
    # similar to column swapper, except it swaps rows

    n_sol = len(solutions)
    L = solutions[rnd.randrange(0, n_sol)]

    num_cols = L.shape[0]
    i = rnd.randrange(0, num_cols)
    j = rnd.randrange(0, num_cols)
    L.iloc[i], L.iloc[j] = L.iloc[j], L.iloc[i]

    return L


def random_swapper_value(solutions):
    """ Swap two random values

        Input: list - list of solutions
        Output: DataFrame - an updated dataFrame after the changes made by the agent
    """

    n_sol = len(solutions)
    L = solutions[rnd.randrange(0, n_sol)]

    col, row = L.shape

    # get the index position to swap
    i1, j1 = rnd.randint(0, col - 1), rnd.randint(0, row - 1)
    i2, j2 = rnd.randint(0, col - 1), rnd.randint(0, row - 1)

    # swap the individual values
    L.iloc[i1, j1], L.iloc[i2, j2] = L.iloc[i2, j2], L.iloc[i1, j1]

    return L


def random_swapper_row_col(solutions):
    """ Swap n number of random rows and cols

        Input: list - list of solutions
        Output: DataFrame - an updated dataFrame after the changes made by the agent

    """
    n_sol = len(solutions)
    L = solutions[rnd.randrange(0, n_sol)]  # a df


    n_sample = 3  # number of rows and cols to change
    n = L.shape[0]
    m = L.shape[1]

    # get the list of rows and cols to swap
    rows1 = np.random.choice(n, n_sample, replace=False)
    rows2 = np.random.choice(list(set(range(n)) - set(rows1)), n_sample, replace=False)
    cols1 = np.random.choice(m, min(n_sample, m), replace=False)
    cols2 = np.random.choice(list(set(range(m)) - set(cols1)), min(n_sample, m), replace=False)

    # swap the values of the two subsets chosen
    df1 = L.iloc[rows1, cols1].copy()
    df2 = L.iloc[rows2, cols2].copy()
    L.iloc[rows1, cols1] = df2.values
    L.iloc[rows2, cols2] = df1.values

    return L





# Non-random agent
def mark_U_as_zeros(solutions):
    """ Purpose: Selects a TA, finds all sections that they are Unavailable
                    Mark those positions as 0 if they are 1 in the solution


        Input: list - list of solutions
        Output: DataFrame - an updated dataFrame after the changes made by the agent

    """
    n_sol = len(solutions)
    L = solutions[rnd.randrange(0, n_sol)]  # pick a random solution df

    # pick a random TA
    num_rows = L.shape[1]
    random_ta = rnd.randrange(0, num_rows)

    # select the row for the chosen TA in both files
    ta_pref = tas.iloc[:, 3:]
    pref = (ta_pref.iloc[random_ta, :])
    asgn = L.iloc[random_ta, :]

    # make sure the index is of the same type
    pref.index = pref.index.astype('int64')

    # change the values within asgn where the value of pref is 'U'
    asgn[pref == 'U'] = 0

    return L


def avoid_overallocation(solutions):
    """ Purpose: Sees if a TA has been over-assigned
                    If so, mark excess sections as 0 randomly


        Input: list - list of solutions
        Output: DataFrame - an updated dataFrame after the changes made by the agent

    """
    n_sol = len(solutions)
    L = solutions[rnd.randrange(0, n_sol)]  # pick a random solution df

    # pick a random TA
    num_rows = L.shape[1]
    random_ta = rnd.randrange(0, num_rows)

    ta_max = tas.max_assigned[random_ta] # maximum sections this chosen TA can teach
    asgn = L.iloc[random_ta, :] # the assignments for this TA

    if sum(asgn) > ta_max:
        diff = sum(asgn) - ta_max # difference between assigned and TA capacity

        # Find the indexes of the values to change
        indexes = asgn[asgn == 1].index.tolist()  # get a list of all indexes where the value is 1

        to_change = rnd.sample(indexes, min(diff, len(indexes)))  # randomly select _ indexes from the list (# to remove)
        asgn.loc[to_change] = 0  # Change the values to 0

    return L



def main():
    # Create framework
    E = Evo()

    # read in the test files
    test1 = pd.read_csv('test1.csv', header=None)
    test2 = pd.read_csv('test2.csv', header=None)
    test3 = pd.read_csv('test3.csv', header=None)

    # create two new test solutions
    test4 = pd.DataFrame(np.ones((43, 17)), dtype=int) # all 1s
    test5 = pd.DataFrame(np.zeros((43, 17)), dtype=int) # all 0s

    # Register some objectives
    E.add_fitness_criteria("overallocation", overallocation_score_func)
    E.add_fitness_criteria("conflict", conflict_score_func)
    E.add_fitness_criteria("undersupport", undersupport_score_func)
    E.add_fitness_criteria("willingness_u", willingness_score_func_U)
    E.add_fitness_criteria("willingness_w", willingness_score_func_W)

    # Register some agents
    E.add_agent("random_swapper_col", random_swapper_col, k=5)
    E.add_agent("random_swapper_row", random_swapper_row, k=5)
    E.add_agent("random_swapper_row_col", random_swapper_row_col, k=5)
    E.add_agent("random_swapper_value", random_swapper_value, k=5)

    E.add_agent("mark_U_as_zeros", mark_U_as_zeros, k=5)
    E.add_agent("avoid_overallocation", avoid_overallocation, k=5)


    # Add solution to Evo
    E.add_solution(test1)
    E.add_solution(test2)
    E.add_solution(test3)
    E.add_solution(test4)
    E.add_solution(test5)



    # print Starting E (for our convenience)
    print("starting E:")
    print(E)
    print("===================================")

    # Run Evolve
    E.evolve(n=10000, dom=100, status=100, sync=1000)
    print("DONE!")

    # Print final results
    print("===================================")
    print("final E:")
    print(E)


if __name__ == '__main__':
    main()
